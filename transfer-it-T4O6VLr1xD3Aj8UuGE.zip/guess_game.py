import random

answers = ['sorry, wrong number. try again !', "yeah, that's it !"]

def guess_game(input_number) :
    return answers

input_number = int(input("guess the number i'm thinking on, from 1 to 10, and type it : "))
random_number = list(range(1, 11))

while input_number != random.choice(random_number) :
    print(int(input('sorry, wrong number. try again : ')))
else :
    print("yeah, that's it !")
